Store and Display Image/ File in MongoDB using nodejs,Express,Mongoose
